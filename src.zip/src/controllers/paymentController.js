const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

const paymentKeyboard = require("../keyboards/paymentKeyboard");

const userService = require("../services/userService");
const planService = require("../services/planService");
const walletService = require("../services/walletService");
const xuiService = require("../services/xuiService");
const orderService = require("../services/orderService");
const purchaseService = require("../services/purchaseService");
const clientService = require("../services/clientService");

const sessionManager = require("../sessions/sessionManager");

async function walletRenew(ctx, serviceId) {
  const telegramId = String(ctx.from.id);

  const user = await prisma.user.findUnique({
    where: {
      telegramId,
    },
  });

  if (!user) {
    return ctx.answerCbQuery("کاربر پیدا نشد");
  }

  const service = await clientService.get(serviceId);

  if (!service) {
    return ctx.answerCbQuery("سرویس پیدا نشد");
  }

  const amount = service.plan.price;

  if (user.balance < amount) {
    return ctx.reply("❌ موجودی کیف پول کافی نیست.");
  }

  await prisma.user.update({
    where: {
      id: user.id,
    },
    data: {
      balance: {
        decrement: amount,
      },
    },
  });

  await prisma.walletTransaction.create({
    data: {
      userId: user.id,
      amount,
      type: "DEBIT",
      description: `تمدید سرویس #${service.id}`,
    },
  });

  const expire =
    new Date(service.expireAt) > new Date()
      ? new Date(service.expireAt)
      : new Date();

  expire.setDate(expire.getDate() + service.plan.days);

  await prisma.service.update({
    where: {
      id: service.id,
    },
    data: {
      expireAt: expire,
    },
  });

  const result = await xuiService.extendClient(service.email, expire.getTime());

  if (!result.success) {
    throw new Error("UPDATE_FAILED");
  }

  await ctx.answerCbQuery();

  return ctx.reply(
    `✅ سرویس با موفقیت تمدید شد.

💰 مبلغ:
${amount.toLocaleString("fa-IR")} تومان

📅 اعتبار جدید:

${expire.toLocaleDateString("fa-IR")}`,
  );
}

module.exports = {
  async select(ctx) {
    return ctx.editMessageText(
      "💳 روش پرداخت را انتخاب کنید.",
      paymentKeyboard,
    );
  },

  async gateway(ctx) {
    return ctx.answerCbQuery("🚧 در حال پیاده‌سازی");
  },

  async card(ctx) {
    return ctx.answerCbQuery("🚧 در حال پیاده‌سازی");
  },

  async wallet(ctx) {
    const session = await sessionManager.get(ctx.from.id);

    if (!session || !session.data) {
      return ctx.editMessageText("❌ اطلاعات خرید پیدا نشد.");
    }

    const { serverId, planId } = session.data;

    try {
      await ctx.editMessageText("⏳ در حال ساخت سرویس...");

      const result = await purchaseService.purchaseWithWallet(
        serverId,
        planId,
        ctx.from.id,
      );

      await sessionManager.clear(ctx.from.id);

      return ctx.editMessageText(
        `✅ سرویس شما با موفقیت ساخته شد.

🌍 ${result.server.country.flag} ${result.server.country.name}

📦 ${result.plan.name}

📧 ${result.client.email}

🔗 لینک اتصال:

${result.subscriptionUrl}`,
      );
    } catch (err) {
      console.error(err);

      if (err.message === "NOT_ENOUGH_BALANCE") {
        return ctx.editMessageText("❌ موجودی کیف پول کافی نیست.");
      }

      return ctx.editMessageText("❌ خطا در ساخت سرویس.");
    }
  },

  walletRenew,
};
