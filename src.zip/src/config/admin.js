module.exports = {
    ADMINS: [
        "1847297788",
        "547472442",
    ]
};